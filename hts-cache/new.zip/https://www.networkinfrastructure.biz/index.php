<!DOCTYPE html>
<html>
	<head>

	
<meta http-equiv="content-type" content="text/html; charset=UTF-8" />
<title>Network Infrastructure :: Home</title>
<meta name="description" content="" />
<meta name="generator" content="concrete5 - 5.6.3.4" />
<script type="text/javascript">
var CCM_DISPATCHER_FILENAME = '/index.php';var CCM_CID = 1;var CCM_EDIT_MODE = false;var CCM_ARRANGE_MODE = false;var CCM_IMAGE_PATH = "/concrete/images";
var CCM_TOOLS_PATH = "/index.php/tools/required";
var CCM_BASE_URL = "https://www.networkinfrastructure.biz";
var CCM_REL = "";

</script>

	<link rel="shortcut icon" href="/files/1814/6539/3001/netinf_16.ico" type="image/x-icon" />
	<link rel="icon" href="/files/1814/6539/3001/netinf_16.ico" type="image/x-icon" />
	<link rel="apple-touch-icon" href="/files/7114/6539/2997/netinf_57.png"  />
<meta name="msapplication-TileImage" content="/files/7414/6539/2991/netinf_144.png" />
<link rel="stylesheet" type="text/css" href="/concrete/css/ccm.base.css" />
<script type="text/javascript" src="/concrete/js/jquery.js"></script>
<script type="text/javascript" src="/concrete/js/ccm.base.js"></script>
<link rel="stylesheet" type="text/css" href="/packages/whale_nivo_slider/blocks/whale_nivo_slider/css/nivo-slider.css" />
<script type="text/javascript" src="/packages/whale_nivo_slider/blocks/whale_nivo_slider/js/jquery.nivo.slider.pack.js"></script>
<link rel="stylesheet" type="text/css" href="/packages/whale_nivo_slider/css/nivo_themes/default/default.css" />
<link rel="stylesheet" type="text/css" href="/concrete/blocks/page_list/view.css" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" type="text/css" media="all" href="/files/cache/css/netinf/css/bootstrap.css" />
	<link rel="stylesheet" type="text/css" media="all" href="/files/cache/css/netinf/css/bootstrap-responsive.css" />
	<link rel="stylesheet" type="text/css" media="all" href="/files/cache/css/netinf/css/font-awesome.css" />
	<link rel="stylesheet" type="text/css" media="all" href="/files/cache/css/netinf/netinf_custom.css" />
	<link rel="stylesheet" type="text/css" media="all" href="/files/cache/css/netinf/typography.css" />
	<link rel="stylesheet" type="text/css" media="all" href="/files/cache/css/netinf/theme-style.css" />
	<link href='https://fonts.googleapis.com/css?family=Lato:400,300,700,900' rel='stylesheet' type='text/css'>
	<script src="https://use.fontawesome.com/669425903a.js"></script>
		<!--[if lt IE 9]>
			<link rel="stylesheet" href="css/font-awesome-ie7.css">
			<script src="//html5shim.googlecode.com/svn/trunk/html5.js"></script>
		<![endif]-->
		<link rel="shortcut icon" href="favicon.ico">
	<style>
		@import url(//fonts.googleapis.com/css?family=Abel);
	</style>
	</head>
	<body>
	<div id="karma">

	<div class="blue-top"></div>
	<div class="gray-fade">
		<div class="container">
			<div class="row-fluid">
				<div class="span6">
					<div style="margin:10px;">
					<img src="/themes/netinf/images/netinf_logo.png" style="height: 120px; width: auto;">
					</div>
				</div>
				<div class="span6">
					<div class="header-right">
												<br><br><br>
						<form method="get" action="/index.php/search/" style="float: right;">
						  <div class="input-append">
							 <input type="text" name="query" value="" placeholder="Search..." />
							 <button class="btn-blue" input type="submit">Search</button>
						  </div>
						</form>
                    </div>
				</div>
			</div>
		</div>
	</div>
	<div class="blue-menu" style="position: relative;">
		<div class="container">
		<div class="row-fluid">
			<div class="span12">
				<div class="navbar">
					<div class="navbar-inner">
						<div class="container">
							<a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">Menu</a>
							<div class="nav-collapse collapse">
								<ul class="nav pull-left"><li class="active active"><a href="/" target="_self" class="active active">Home</a></li><li class="dropdown "><a class="dropdown-toggle" data-hover="dropdown" href="/about-us/company-history/" target="_self" class="">About Us <b class="caret"></b></a><ul class="dropdown-menu"><li class=""><a href="/about-us/company-history/" target="_self" class="">Company History</a></li><li class=""><a href="/about-us/mission-statement/" target="_self" class="">Mission Statement</a></li><li class=""><a href="/about-us/management-team/" target="_self" class="">Management Team</a></li></ul></li><li class=""><a href="/professional-services/" target="_self" class="">Professional Services</a></li><li class=""><a href="/health-safety/" target="_self" class="">Health & Safety</a></li><li class=""><a href="/employment/" target="_self" class="">Employment</a></li><li class=""><a href="/training-academy/" target="_self" class="">Training Academy</a></li><li class=""><a href="/news/" target="_self" class="">News</a></li><li class=""><a href="/projects/" target="_self" class="">Projects</a></li><li class=""><a href="/contact-us/" target="_self" class="">Contact Us</a></li></ul>							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		</div>
	</div>

<div class="container wrapper">
	<div class="wra">


		<div class="row-fluid">
			<div class="span12 slideshow">
				
	<div class="slider-wrapper theme-default" id="slider-wrapper-39">
	    <div id="nivo-slider-39" class="nivoSlider" style="width: 100% !important;">
		<img src="/files/1714/6541/7387/banner_1.png" alt="banner_1.png" title="" data-thumb="/files/1714/6541/7387/banner_1.png" ><img src="/files/4314/6541/7389/banner_2.png" alt="banner_2.png" title="" data-thumb="/files/4314/6541/7389/banner_2.png" ><img src="/files/2814/6541/7390/banner_3.png" alt="banner_3.png" title="" data-thumb="/files/2814/6541/7390/banner_3.png" >        </div>
	</div>

<script type="text/javascript">
$(document).ready(function() {
	$('#nivo-slider-39').nivoSlider({
		effect: 'random',         slices: 15,         boxCols: 8,         boxRows: 4,         animSpeed: 1000,         pauseTime: 8000,         startSlide: 0,         directionNav: 0,         controlNav: 0,         controlNavThumbs: 0,         pauseOnHover: 0,         manualAdvance: 0,         prevText: 'Prev',         nextText: 'Next',         randomStart: 1                                         	});
	
});
</script>
<br style="clear: both;" />
			</div>
		</div>

		<div class="big-buttons-home">
			<div class="row-fluid">
				<div class="span6">
					<center>
										</center>
				</div>
				<div class="span6">
					<center>
										</center>
				</div>
			</div>
		</div>

		<!--<div class="big-buttons-home">
			<div class="row-fluid">
				<div class="span3">
					<center>
					<a href="/professional-services/gas/"><img border="0" class="ccm-image-block" alt="" src="/files/6614/6541/8305/btn_1.png" width="247" height="247" /></a>					</center>
				</div>
				<div class="span3">
					<center>
					<a href="/professional-services/telecom/"><img border="0" class="ccm-image-block" alt="" src="/files/8614/6541/8305/btn_2.png" width="247" height="247" /></a>					</center>
				</div>
				<div class="span3">
					<center>
					<img border="0" class="ccm-image-block" alt="" src="/files/9414/6541/8305/btn_3.png" width="247" height="247" />					</center>
				</div>
				<div class="span3">
					<center>
					<img border="0" class="ccm-image-block" alt="" src="/files/1814/6541/8306/btn_4.png" width="247" height="247" />					</center>
				</div>
			</div>
		</div>-->

		<div class="row-fluid">
			<div class="span7">
				<div class="content-area" style="margin-top: 15px; margin-left: 10px;">
					<p><strong>Network Infrastructure, Inc.</strong> is a versatile utility contracting company that delivers <a title="About Us" href="/about-us/">exceptional value</a> to America’s utilities. We specialize in utility asset management and contracting, delivering end-to-end solutions to the gas, telecommunications, electric, water and sewer industries. Network Infrastructure is an integrated, full-service partner that provides outsourced turnkey solutions and complete infrastructure asset management. We work regionally throughout the northeast, including NYC’s five boroughs, and generate substantial savings through efficient resource utilization.<br /> <br /> We have a cross-trained union workforce with a wide variety of skills, which allows us to shift resources seamlessly. Our flexibility allows us to maintain the best-qualified labor pool in the region, a substantial challenge given the volatility of utility workloads. It also keeps costs down and helps us complete projects on time - or ahead of schedule.<br /> <br /> We incorporate the best of next-generation technology while embracing essential old world values. When Network Infrastructure is on the job, we work as a team, and we consistently deliver the results that the client needs. The value we add to a project ensures client satisfaction and positions us to be a preferred contractor in the future. It's a formula we trust, and it has helped us grow to more than 300 employees since our founding in 1999.</p>				</div>
			</div>
			<div class="span5">
							</div>
		</div>

		<div class="row-fluid">
			<div class="span12">
				<div class="content-area">
				<div id="blog-index">
<div class="row-fluid">

		
</div>	
</div>


	</div>
				</div>
			</div>
		</div>

	</div>


	</div>
</div>
		<!--<div class="container">
	<footer>
		<div class="footer-line">
				<p class="pull-right"><a href="#"><i class="icon-arrow-up backtotop"></i> Back to top</a></p>
						</div>
	</footer>
	</div>-->
<div class="footer-background">	
	<div class="footer-gradient">
		<div class="container">
			<div class="row-fluid hidden-phone">
				<div class="span12">
					<div class="white-footer">
						<p style="text-align: left !important;">GAS • TELECOM<!-- • ELECTRIC • WATER • SEWER--></p>
					</div>
				</div>
			</div>
			
			<div class="content-area">
			<div class="row-fluid" style="margin-top: 10px;">
				<div class="span4">
					<p><strong>NETWORK INFRASTRUCTURE, Inc.</strong><br />94 Taft Avenue, Hempstead, New York 11550</p>
<p><span style="font-size: x-large;"><strong>516-385-3030</strong></span></p>
						<a href="https://www.facebook.com/Network-Infrastructure-Inc-101671846555908" target="_blank"><i class="fa fa-facebook-square fa-2x" aria-hidden="true"></i></a>&nbsp;&nbsp;<a href="https://www.linkedin.com/company-beta/1501728" target="_blank"><i class="fa fa-linkedin-square fa-2x" aria-hidden="true"></i></a>
				</div>
				<!--<div class="span3">
					<a href="#" target="_blank"><i class="fa fa-facebook-square fa-3x" aria-hidden="true"></i></a>&nbsp;&nbsp;
					<a href="#" target="_blank"><i class="fa fa-twitter-square fa-3x" aria-hidden="true"></i></a>&nbsp;&nbsp;
					<a href="#" target="_blank"><i class="fa fa-google-plus-square fa-3x" aria-hidden="true"></i></a>				
				</div>-->
				<div class="span8 hidden-phone">
					<p style="text-align: right;"><img src="/files/cache/7266efd5d3dec9fdd6873e380c8b40d9_f4.png" alt="lica_logo.png" width="135" height="74" />        <img src="/files/cache/f7612afbb5438e022ac794fefb9e576a_f5.png" alt="nuca_logo.png" width="263" height="75" /></p>				
				</div>
			</div>
			
			<div class="row-fluid">
				<div class="span12">
					<p>&copy 2020 Network Infrastructure, Inc. All rights reserved. <a href="https://www.networkinfrastructure.biz/sitemap">Sitemap</a> | Site by <a href="http://www.primediany.com" target="_blank">PriMedia</a>.</p>
				</div>
			</div>
			</div>
		</div>
	</div>
</div>	
	
	
</div>
</div>
	<script src="/themes/netinf/js/bootstrap.min.js"></script>
	<script src="/themes/netinf/js/twitter-bootstrap-hover-dropdown.js"></script>
	
		</body>
</html>
